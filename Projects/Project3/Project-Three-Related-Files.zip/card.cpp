#include "card.h"
// Suit names
const char *SuitNames[] = {"Spades", "Hearts", "Clubs", "Diamonds"};
// Spot names
const char *SpotNames[] = {"Two", "Three", "Four", "Five", "Six", 
                           "Seven", "Eight", "Nine", "Ten", "Jack", 
                           "Queen", "King", "Ace"};
